/*
File name: PageProvider.h
Function: Provide html pages and other static resources for front-end pages
*/

#pragma once

void InitPageProvider();