#pragma once

#ifndef _IMGUI_UI_H_
#define _IMGUI_UI_H_

namespace UI
{
	void InitIMGUI();
	void ImGUILoop();
}

#endif