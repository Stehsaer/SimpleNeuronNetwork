#pragma once
#ifndef _ACT_FUNC_H_
#define _ACT_FUNC_H_

enum class ActivateFunctionType
{
	Sigmoid, SigmoidShifted, ReLU
};



#endif
