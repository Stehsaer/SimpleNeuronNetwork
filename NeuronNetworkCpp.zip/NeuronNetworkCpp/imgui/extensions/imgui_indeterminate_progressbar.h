#pragma once

#ifndef _IMGUI_IND_PROGRESS_H_
#define _IMGUI_IND_PROGRESS_H_

#include "../imgui.h"

namespace ImGui
{
	void IndeterminateProgressBar(const ImVec2& size);
}

#endif