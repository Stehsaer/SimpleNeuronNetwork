/*
File name: MainNetworkInstance.h
Function: Contains main network objects needed for main thread
*/

#pragma once
#ifndef _NETWORK_INSTANCE_H_
#define _NETWORK_INSTANCE_H_

#include "Network.h"
#include <string>

#define MAX_DATASET_COUNT 4

enum class serverStatus
{
	Idle,
	Query,
	Working
};

extern std::string status_text;
extern float serverProgress;
extern Network::Framework::BackPropaNetwork* network;
extern serverStatus server_status;
extern Network::NetworkDataSet datasets[MAX_DATASET_COUNT];

void MainThread();

const std::string datasetPath = "web_res/datasets/";
const std::string webPagePath = "web/";


#endif