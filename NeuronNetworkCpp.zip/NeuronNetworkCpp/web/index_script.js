var server_status_json;

function update_elements()
{
    $("#server-status-text").html(server_status_json["status_text"]);

    if(server_status_json["network_info"] == null)
    {
        $("#server-network-text").text("Not loaded");
    }
    else
    {
        $("#server-network-text").text("Stand by");
    }

    var max_dataset_num = server_status_json["max_dataset_num"];
    $("#dataset-table>tbody").empty();

    server_status_json["datasets_info"].forEach(element => 
        {
        var name = element["name"];
        if(name == "") name = "--";

        var data_height = element["data_height"];
        var data_width = element["data_width"];
        var data_count = element["data_count"];
        var data_space = Math.round(data_height*data_width*data_count*4 / 1048576, 2);

        $("#dataset-table>tbody").
            append(`<tr><td>${name}</td><td>(${data_height}, ${data_width})</td><td>${data_count}</td><td>${data_space} MB</tr>`)
    });
}

function interval_update()
{
    var request = new XMLHttpRequest();

    request.onreadystatechange = function()
    {
        if(request.readyState == 4) // ready
        {
            if(request.status == 200) // success
            {
                server_status_json = JSON.parse(request.responseText);
            }
            if(request.status >= 400) // error
            {
                console.log("Can't fetch status from server");
            }

            update_elements();

            setTimeout(interval_update, 1000);
        }
    }

    request.open("GET", "/api/query/status");
    request.send(null);
}

interval_update();