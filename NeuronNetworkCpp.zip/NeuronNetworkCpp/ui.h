#pragma once

#ifndef _UI_H_
#define _UI_H_

#include "UIState.h"

namespace UI
{
    void MainLoop();
}

#endif