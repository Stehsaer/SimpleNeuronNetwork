clang -std=c++17 *.cpp -lstdc++ -lm -O2
