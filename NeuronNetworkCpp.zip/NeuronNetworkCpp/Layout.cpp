#include <iostream>
#include <vector>
#include <thread>

#include "uni_imgui.h"
#include "imgui/extensions/imgui_indeterminate_progressbar.h"

#include "UIState.h"
#include "UIStyle.h"
#include "Tasks.h"

#include "MathHelper.h"

#include "fonts/RemixIconFontDef.h"

namespace UI
{
	void DrawLayout();

	namespace Layout
	{
		// layout constants
		const int bottomBarHeight = 40;
		const int rightPanelWidth = 400;
		
		// element flags
		bool showDemoWindow = false;

		namespace Util
		{
			namespace FrametimeRecorder
			{
				float frametimeNow;

				std::vector<float> frameTimeList;
				const int maxRecord = 300;
				float frameTimes[maxRecord];

				const ImGui::SimplePlot::PlotConfig frametimeGraphConfig
				{
					.values = ImGui::SimplePlot::PlotConfig::Values
					{
						.ys = &frameTimes[0],
						.count = maxRecord
					},
					.scale = ImGui::SimplePlot::PlotConfig::Scale
					{
						.min = 0.0f, .max = 100.0f
					},
					.tooltip = ImGui::SimplePlot::PlotConfig::Tooltip
					{
						.show = false
					},
					.grid_x = ImGui::SimplePlot::PlotConfig::Grid
					{
						.show = true,
					},
					.grid_y = ImGui::SimplePlot::PlotConfig::Grid
					{
						.show = true,
						.size = 20,
						.subticks = 4
					},
					.frame_size = ImVec2(400,200),
					.line_thickness = 2.0f
				};

				void RecordFPS()
				{
					frametimeNow = ImGui::GetIO().DeltaTime * 1000.0f;
					frameTimeList.push_back(frametimeNow);
					if (frameTimeList.size() > maxRecord) frameTimeList.erase(frameTimeList.begin());
				}

				void DisplayFPSGraph()
				{
					for (int i = 0; i < maxRecord; i++)
					{
						if (i < frameTimeList.size())
							frameTimes[i] = frameTimeList[i];
						else
							frameTimes[i] = 0.0f;
					}

					ImGui::BulletText("Avg Frame time: %.1fms", 1000.0f / ImGui::GetIO().Framerate);

					//ImGui::PlotLines("##frametime_plot", [](void* data, int idx) {return (*(std::vector<float>*) data)[idx]; }, &frameTimeList, frameTimeList.size(), 0, 0, 0.0, FLT_MAX, ImVec2(400, 200));
					ImGui::SimplePlot::Plot("##frametime_plot", frametimeGraphConfig);
				}
			}
		}

		namespace Workload
		{
			namespace Datasets
			{
				int selectedItem = -1;
				std::string name;

				void Load()
				{
					if (Tasks::taskProgress.Ready() && selectedItem >= 0)
					{
						std::thread thread(Tasks::LoadDataset, Tasks::Instances::datasetDirs[selectedItem], name);
						thread.detach();
					}
				}
			}
		}

		void MainTabBars()
		{
			// settings tab
			if(ImGui::BeginTabItem(ICON_SETTINGS_FILL" Settings##settings_tab", NULL, ImGuiTabItemFlags_None))
			{

				// Style options
				ImGui::SeparatorText("Style & Graphics");
				ImGui::Spacing();
				ImGui::BeginGroup();
				{
					const ImVec2 StyleButtonSize(80, 30);
					if (ImGui::Button("Dark", StyleButtonSize)) ImGui::StyleColorsDark(); ImGui::SameLine();
					if (ImGui::Button("Classic", StyleButtonSize)) ImGui::StyleColorsClassic(); ImGui::SameLine();
					if (ImGui::Button("Light", StyleButtonSize)) ImGui::StyleColorsLight(); ImGui::SameLine();
					if (ImGui::Button("Custom 1", StyleButtonSize)) Style::CustomStyle1();
				}
				ImGui::EndGroup();

				ImGui::Spacing();
				ImGui::Checkbox("Vsync Enabled", &UI::windowVsync);

				// Debug options
				ImGui::SeparatorText("Debug");
				ImGui::Checkbox("Show Demo Window", &showDemoWindow);

				ImGui::Spacing();
				Util::FrametimeRecorder::RecordFPS();

				if (ImGui::TreeNode("Performance"))
				{
					ImGui::BulletText("Avg Framerate: %.0f FPS", ImGui::GetIO().Framerate);
					Util::FrametimeRecorder::DisplayFPSGraph();

					ImGui::TreePop();
				}

				ImGui::NewLine();

				ImGui::EndTabItem();
			}

			if(ImGui::BeginTabItem(ICON_DATABASE_2_FILL " Dataset##dataset_tab", NULL, ImGuiTabItemFlags_None))
			{
				ImGui::BeginChild("DatasetList##dataset_list", ImGui::GetContentRegionAvail(), false, ImGuiWindowFlags_NoDecoration);
				
				{ // Load Dataset
					ImGui::SeparatorText("Load Dataset");
					ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x);
					if (ImGui::BeginListBox("##dataset_listbox"))
					{
						int i = 0;
						for (auto& str : Tasks::Instances::datasetDirs)
						{
							const bool isSelected = (i == Workload::Datasets::selectedItem);

							if (ImGui::Selectable(str.c_str(), isSelected))
							{
								Workload::Datasets::selectedItem = isSelected ? -1 : i;
							}

							if (isSelected) ImGui::SetItemDefaultFocus();

							i++;
						}
						ImGui::EndListBox();
					}
					
					if (ImGui::Button("Load##load_dataset_button"))
					{
						Workload::Datasets::Load();
					}
					ImGui::SameLine();
					ImGui::InputText("Name", &Workload::Datasets::name);
					
				}
				
				ImGui::EndChild();
				ImGui::EndTabItem();
			}
		}

		void RightPanel()
		{
			ImGui::SeparatorText("Assets");
			ImGui::Spacing();

			ImGui::BulletText("Datasets Loaded: %d", Tasks::Instances::datasets.size());

			std::vector<Network::NetworkDataSet*>& datasets = Tasks::Instances::datasets;
			if (datasets.size() > 0)
				if (ImGui::BeginTable("DatasetTable##right_panel_dataset_table", 4, ImGuiTableFlags_SizingStretchProp | ImGuiTableFlags_Borders | ImGuiTableFlags_RowBg))
				{
					// header
					ImGui::TableNextRow(ImGuiTableRowFlags_Headers);
					ImGui::TableNextColumn(); ImGui::Text("Name");
					ImGui::TableNextColumn(); ImGui::Text("Count");
					ImGui::TableNextColumn(); ImGui::Text("Width");
					ImGui::TableNextColumn(); ImGui::Text("Height");

					for (int i = 0; i < datasets.size(); i++)
					{
						ImGui::TableNextRow();
						ImGui::TableNextColumn(); ImGui::Text("%s", datasets[i]->name.c_str());
						ImGui::TableNextColumn(); ImGui::Text("%d", datasets[i]->Count());
						ImGui::TableNextColumn(); ImGui::Text("%d", datasets[i]->dataWidth);
						ImGui::TableNextColumn(); ImGui::Text("%d", datasets[i]->dataHeight);
					}

					ImGui::EndTable();
				}
		}

		void DrawMainPanel()
		{
			ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 0);

			const int panelFlag = ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoBringToFrontOnFocus;

			// Left Main panel
			{
				ImGui::SetNextWindowPos(ImVec2(0, 0));
				ImGui::SetNextWindowSize(ImVec2(windowWidth - rightPanelWidth, windowHeight - bottomBarHeight));

				ImGui::Begin("MainWindow##main_window", NULL, panelFlag);

				ImGui::BeginTabBar("MainTab##main_tab", ImGuiTabBarFlags_None);

				MainTabBars();

				ImGui::EndTabBar();

				ImGui::End();
			}

			// Bottom status bar
			{
				ImGui::SetNextWindowPos(ImVec2(0, windowHeight - bottomBarHeight));
				ImGui::SetNextWindowSize(ImVec2(windowWidth, bottomBarHeight));

				ImGui::Begin("Bottom Bar##bottom_bar", NULL, panelFlag);

				// status text
				const char* statusIcons[] = { ICON_ZZZ_FILL, ICON_PLAY_FILL, ICON_CHECK_DOUBLE_FILL, ICON_ERROR_WARNING_FILL };
				ImGui::Text("%s %s", statusIcons[(int)Tasks::taskProgress.state], Tasks::taskProgress.display.c_str());

				// progress bar
				ImGui::SameLine();

				if (Tasks::taskProgress.state == Tasks::TaskState::Working)
					if (Tasks::taskProgress.isIndeterminate)
					{
						ImGui::IndeterminateProgressBar(ImVec2(250, 0));
					}
					else
					{
						ImGui::ProgressBar(-1, ImVec2(250, 0));
					}


				ImGui::End();
			}

			// Right panel
			{
				ImGui::SetNextWindowPos(ImVec2(windowWidth, 0), 0, ImVec2(1, 0));
				ImGui::SetNextWindowSize(ImVec2(rightPanelWidth, windowHeight - bottomBarHeight));

				ImGui::Begin("Right Panel##right_panel", NULL, panelFlag);

				RightPanel();

				ImGui::End();
			}

			ImGui::PopStyleVar(1);
		}
	}

	void DrawLayout()
	{
		Layout::DrawMainPanel();

		if (Layout::showDemoWindow)
			ImGui::ShowDemoWindow();
	}
}