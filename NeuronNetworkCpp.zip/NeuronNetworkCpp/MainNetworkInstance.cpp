#include "MainNetworkInstance.h"

serverStatus server_status = serverStatus::Idle;
std::string status_text = "Idle";
float serverProgress = 0.0f;

Network::Framework::BackPropaNetwork* network = nullptr;

Network::NetworkDataSet datasets[MAX_DATASET_COUNT];