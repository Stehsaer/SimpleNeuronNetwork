#pragma once

#ifndef _UI_STYLE_H_
#define _UI_STYLE_H_

namespace UI
{
	namespace Style
	{
		void CustomStyle1();
	}
}

#endif