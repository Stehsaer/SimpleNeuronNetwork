#include "Tasks.h"

namespace Tasks
{
	Progress taskProgress("Idle");

	void Progress::Idle()
	{
		state = TaskState::Idle;
		display = "Idle";
	}

	void Progress::Work(std::string txt)
	{
		state = TaskState::Working;
		display = txt;
	}

	void Progress::Done(std::string txt)
	{
		state = TaskState::Done;
		display = txt;
	}

	void Progress::Error(std::string txt)
	{
		state = TaskState::Error;
		display = txt;
	}

	bool Progress::Ready()
	{
		return state == TaskState::Idle;
	}

	void Progress::Set(float progress, std::string display)
	{
		this->isIndeterminate = false;
		this->progress = progress;
		this->display = display;
	}

	void Progress::SetIndeterminate(std::string display)
	{
		this->isIndeterminate = true;
		this->progress = 0.0f;
		this->display = display;
	}

	namespace Instances
	{
		const int maxDatasetCount = 8;
		const std::string datasetPath = "resources/datasets/";
		const std::string modelPath = "resources/models/";

		Network::Framework::FullConnNetwork* mainNetwork = NULL;
		std::vector<Network::NetworkDataSet*> datasets;

		//std::vector<FileInfo> datasetFiles;
		std::vector<std::string> datasetDirs;

		void ReadFileList(std::vector<FileInfo>& list, std::string path, std::initializer_list<const char*> filters)
		{
			list.clear();

			namespace fs = std::filesystem;

			for (auto& iter : fs::directory_iterator(path))
			{
				if (!fs::is_directory(iter.status()))
				{
					FileInfo info(iter.path().string());

					bool filtered = false;
					for (auto ext = filters.begin(); ext != filters.end(); ext++)
					{
						if (info.name.ends_with(*ext))
						{
							filtered = true;
							break;
						}
					}

					if (filtered) list.push_back(info);
				}
			}
		}

		void ReadDirList(std::vector<std::string>& list, std::string path)
		{
			list.clear();

			namespace fs = std::filesystem;

			for (auto& iter : fs::directory_iterator(path))
			{
				if (fs::is_directory(iter.status()))
				{
					std::string str = iter.path().string();
					list.push_back(str.substr(str.find_last_of('/') + 1, str.size()));
				}
			}
		}

		bool RemoveDataset(int slot)
		{
			try
			{
				if (slot >= datasets.size()) return false;

				datasets[slot]->Destroy();
				delete datasets[slot];

				datasets.erase(datasets.begin() + slot);

				return true;
			}
			catch (std::exception e)
			{
				return false;
			}
		}

		bool AddDataset(Network::NetworkDataSet* dataset)
		{
			if (datasets.size() >= maxDatasetCount)
			{
				return false;
			}

			datasets.push_back(dataset);

			return true;
		}
	}

	void LoadDataset(std::string path, std::string name)
	{
		try
		{
			taskProgress.Work("Loading Dataset");
			taskProgress.SetIndeterminate();

			if (Instances::datasets.size() >= Instances::maxDatasetCount)
				throw std::exception("Dataset slot full!");

			Network::NetworkDataSet* set = new Network::NetworkDataSet(name);
			Network::NetworkDataParser::ReadMNISTData(set, Instances::datasetPath + path + "/image", Instances::datasetPath + path + "/label", Network::Algorithm::ZeroToOne);

			Instances::AddDataset(set);

			taskProgress.Done();
		}
		catch (std::exception e)
		{
			taskProgress.Error(e.what());
		}
	}
}